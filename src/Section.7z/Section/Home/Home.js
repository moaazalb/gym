import Bannar from '../../Components/Bannar/Bannar'
import  Navbar  from '../../Components/Navbar/Navbar'
import './Home.css'

const Home = () => {
    return (
        <>
     <Navbar/>
     <Bannar/>
     </>
    )
}

export default Home