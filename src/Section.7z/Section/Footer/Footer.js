import './Footer.css'

const Footer = () => {
    return (
        <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>phone &copy; 0936862796
                    
                    - Designed by <a rel="nofollow" href="https://templatemo.com" class="tm-text-link" target="_parent">Moaaz Albari</a></p>
                    
                   
                </div>
            </div>
        </div>
    </footer>
    )
}
export default Footer