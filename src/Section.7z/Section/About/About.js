import './About.css'
import Features from '../../Components/Features/Features'
const About = () => {
    return (
        <>
      
    <Features/>
    </>
    )
}


export default About